//
//  ViewController.swift
//  TicTacToe
//
//  Created by Sumrin Mudgil on 1/19/19.
//  Copyright © 2019 Sumrin Mudgil. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    
    @IBOutlet weak var newGameButton: UIButton!
    @IBOutlet weak var board: UICollectionView!
    @IBOutlet weak var currentPlayerImage: UIImageView!
    var items = [-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1] //-1 denotes empty cell; 1 denotes used by player 1; 0 means used by player 2
    var isFirstsTurn = 1 //when this value is 1, means its player 1's turn; when it's 0, it means that it is player 2's turn
    var p1_used = Set<Int>() //keeps track of board indices covered by player 1
    var p2_used = Set<Int>() //keeps track of board indices covered by player 2
    var count = 0 //variable keeps track of number of board indices used; ulitimately used to determine if there's a tie at the end

    
    //variables used to set the padding in the grid
    var boardWidth = 0.0
    var padding = 0.00
    
    override func viewDidLoad() {
        super.viewDidLoad()
        board.register(UINib.init(nibName: "SimpleCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "simpleCell") //just a simple collection view cell
        
        newGameButton.layer.cornerRadius = newGameButton.bounds.height / 2 //gives button rounded corners
        newGameButton.layer.borderColor = UIColor(red: 250/255, green: 120/255, blue: 56/255, alpha: 1).cgColor
        newGameButton.layer.borderWidth = 1
        
        boardWidth = Double(board.bounds.width)
        padding = (boardWidth / 5) / 4
        
        board.delegate = self
        board.dataSource = self
        board.reloadData()
        
        currentPlayerImage.image = #imageLiteral(resourceName: "happy")
    }

    override func viewDidAppear(_ animated: Bool) {
        presentWelcomeMessage()
    }
    
    //Presents welcome message
    func presentWelcomeMessage() {
        let alert = UIAlertController(title: "Welcome to 4x4 TicTacToe!", message: "To win, you must get 4 in row (vertical/horizontal/diagonal), all 4 corners, a 2x2 box. Player 1 (☺️) starts, and player 2 (😜) follows.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "START", style: .cancel, handler: nil))
        self.present(alert, animated: true,completion: nil)
    }
    
    //Restarts the game
    @IBAction func newGameClicked(_ sender: Any) {
        currentPlayerImage.image = #imageLiteral(resourceName: "happy")
        isFirstsTurn = 1
        p1_used.removeAll()
        p2_used.removeAll()
        items =  [-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1]
        board.reloadData()
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.items.count
    }
    
    //Sets size of elements
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        let yourWidth = board.bounds.width/5
        let yourHeight = yourWidth
        
        return CGSize(width: yourWidth, height: yourHeight)
    }
    
    //Sets board padding
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: CGFloat(padding), left: CGFloat(padding), bottom: CGFloat(padding), right: CGFloat(padding))
    }
    
    //Determines image (or lack there of) at that cell
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "simpleCell", for: indexPath) as! SimpleCollectionViewCell
        if items[indexPath.row] == 0 {
            cell.imageView.image = #imageLiteral(resourceName: "wink")
        } else if items[indexPath.row] == 1 {
            cell.imageView.image = #imageLiteral(resourceName: "happy")
        } else {
            cell.imageView.image = nil
        }
        
        return cell
    }
    
    //Determines action when user selects a cell
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if items[indexPath.row] == -1 { //cell is empty
            items[indexPath.row] = isFirstsTurn
            if (isFirstsTurn == 0) {
                p2_used.insert(indexPath.row) //adds that index to set of indices covered by player 2
                isFirstsTurn = 1
                currentPlayerImage.image = #imageLiteral(resourceName: "happy")
            } else {
                p1_used.insert(indexPath.row)
                isFirstsTurn = 0
                currentPlayerImage.image = #imageLiteral(resourceName: "wink")
            }
            count += 1
            checkIfWinner(justAdded: indexPath.row)
            board.reloadData()
        } else { //cell is already filled
            let alert = UIAlertController(title: "Uh oh...that spot is taken.", message: "Please select an empty square.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            self.present(alert, animated: true,completion: nil)
        }
    }
    
    //checks if the player who just made a turn is a winner
    func checkIfWinner(justAdded: Int) {
        var winnerExists = false
        if (isFirstsTurn == 0) {
            winnerExists = checkFourCorners(toCheckSet: p1_used) ||  checkSquare(toCheckSet: p1_used, currIndex: justAdded) || checkFourInRow(toCheckSet: p1_used, currIndex: justAdded)
        } else {
            winnerExists = checkFourCorners(toCheckSet: p2_used) ||  checkSquare(toCheckSet: p2_used, currIndex: justAdded) || checkFourInRow(toCheckSet: p2_used, currIndex: justAdded)
        }
        if winnerExists {
            printWinnerMessage()
        } else if count == 0 {
            printTieMessage()
        }
        
    }
    
    //Presents an alert that tells us who is the winner.
    func printWinnerMessage() {
        var message = ""
        if (isFirstsTurn == 1) {
            message = "Player two has won!"
        } else {
            message = "Player one has won!"
        }
        let alert = UIAlertController(title: "Looks like we have a winner...", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { action in
            self.newGameClicked(self)
        }))
        self.present(alert, animated: true,completion: nil)
    }
    
    //Presents an alert that tells us there's a tie.
    func printTieMessage() {
        let alert = UIAlertController(title: "And the winner is...", message: "BOTH of you! It's a tie!", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { action in
            self.newGameClicked(self)
        }))
        self.present(alert, animated: true,completion: nil)
    }

    
    //Checks if four outermost corners are filled
    func checkFourCorners(toCheckSet: Set<Int>) -> Bool {
        print("corn")

        return toCheckSet.contains(0) && toCheckSet.contains(3) && toCheckSet.contains(12) && toCheckSet.contains(15)
    }
    
    //Checks if there's a square
    func checkSquare(toCheckSet: Set<Int>, currIndex: Int) -> Bool {
        var squareExists = false
        let topLeft = toCheckSet.contains(currIndex - 5)
        let topRight = toCheckSet.contains(currIndex - 3)
        let botLeft = toCheckSet.contains(currIndex + 3)
        let botRight = toCheckSet.contains(currIndex + 5)
        
        if !topLeft && !topRight && !botLeft && botRight {
            return false
        }
        
        if topLeft && !squareExists { //check top left square
            print("tlft")
            return toCheckSet.contains(currIndex - 4) && toCheckSet.contains(currIndex - 1)
        }
        
        if topRight && !squareExists { //check top right square
            print("trt")
             squareExists = toCheckSet.contains(currIndex - 4) && toCheckSet.contains(currIndex + 1)
        }
        
        if botLeft && !squareExists { //check bottom left square
            print("bleft")
             return toCheckSet.contains(currIndex + 4) && toCheckSet.contains(currIndex - 1)
        }
        
        if botRight && !squareExists { //check bottom right square
            print("brt")
            return toCheckSet.contains(currIndex + 4) && toCheckSet.contains(currIndex + 1)
        }
        print("sq")
        return squareExists
    }
    
    //Checks if four in row--> diagonally, vertically, and horizontally
    func checkFourInRow(toCheckSet: Set<Int>, currIndex: Int) -> Bool {
        return checkDiag(toCheckSet: toCheckSet) || checkVertical(toCheckSet: toCheckSet, currIndex: currIndex) || checkHorizontal(toCheckSet: toCheckSet, currIndex: currIndex)
    }
    
    //Checks if four in row horizontally
    func checkHorizontal(toCheckSet: Set<Int>, currIndex: Int) -> Bool {
        var numSameRow = 0
        var indexCpy = currIndex
        
        while (toCheckSet.contains(indexCpy)) { //go right
            print("going right\(indexCpy)")
            if(indexCpy % 4 == 3) { //about to wrap to next row
                break
            }

            numSameRow += 1
            indexCpy += 1
        }
        indexCpy = currIndex - 1
        
        while (toCheckSet.contains(indexCpy)) { //go left
            print("going left\(indexCpy)")
            if(indexCpy % 4 == 0) { //about to wrap to previous row
                break
            }
            numSameRow += 1
            indexCpy -= 1
        }
        print("row")

        return numSameRow == 4
    }
    
    //Checks if four in row vertically
    func checkVertical(toCheckSet: Set<Int>, currIndex: Int) -> Bool {
        var numSameCol = 0
        var indexCpy = currIndex
        while (toCheckSet.contains(indexCpy)) { //go up
                numSameCol += 1
                indexCpy -= 4
        }
        indexCpy = currIndex + 4
        while (toCheckSet.contains(indexCpy)) { //go down
            numSameCol += 1
            indexCpy += 4
        }
        print("vertical")
        return numSameCol == 4
    }
    
    //Checks both diagonals if they are filled
    func checkDiag(toCheckSet: Set<Int>) -> Bool {
        print("diag")

       return (toCheckSet.contains(0) && toCheckSet.contains(5) && toCheckSet.contains(10) && toCheckSet.contains(15)) || (toCheckSet.contains(3) && toCheckSet.contains(6) && toCheckSet.contains(9) && toCheckSet.contains(12))
    }
    
}

