//
//  SimpleCollectionViewCell.swift
//  TicTacToe
//
//  Created by Sumrin Mudgil on 1/19/19.
//  Copyright © 2019 Sumrin Mudgil. All rights reserved.
//

import UIKit

class SimpleCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var imageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
